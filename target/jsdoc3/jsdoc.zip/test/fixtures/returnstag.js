/**
*  @returns { String | Array<String>}  The names of the found item(s).
*/
function find(targetName) {
}

/**
*  @return The binding id.
*/
function bind(callback) {
}

// This test exists because there used to be a bug in jsdoc which
// would cause it to fail parsing.
/**
*  @return An object to be passed to {@link find}.
*/
function convert(name) {
}
