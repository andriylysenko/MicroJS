/**
    @ignore
*/
function foo(x) {
    
}
