Klass('trackr.CookieManager',

    /** @class
        @alias trackr.CookieManager
        @param {object} kv
    */
    function(kv) {
        /** document me */
        this.value = kv;
    }
    
);